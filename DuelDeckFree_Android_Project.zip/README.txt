무료 듀얼덱 메이커 - Android Studio 프로젝트

중요
- 이 ZIP은 APK 파일이 아니라 APK를 빌드할 수 있는 Android Studio 프로젝트 소스입니다.
- 현재 제작 환경에는 Android SDK/Gradle 빌드 도구가 없어 APK 바이너리를 직접 컴파일하지 못했습니다.
- Claude API는 전혀 사용하지 않습니다. 덱 조합은 앱 내부 JavaScript 규칙으로 실행됩니다.
- 플레이어 정보를 불러오려면 Clash Royale API 키와 인터넷 연결이 필요합니다.
- API 키는 앱의 SharedPreferences에 이 기기 로컬로 저장됩니다.

APK 빌드 방법
1. PC에 Android Studio를 설치합니다.
2. 압축을 풀고 Android Studio에서 DuelDeckFree 폴더를 Open 합니다.
3. Gradle Sync가 끝날 때까지 기다립니다.
4. Build > Build Bundle(s) / APK(s) > Build APK(s)를 선택합니다.
5. 완료 알림의 locate를 눌러 app-debug.apk를 찾습니다.
6. APK를 휴대폰으로 옮겨 설치합니다.

사용 방법
1. 앱을 열고 Clash Royale API 키를 입력합니다.
2. 플레이어 태그를 입력합니다. 예: #ABC123
3. 3개 또는 4개 덱과 선호 스타일을 선택합니다.
4. 덱 만들기를 누릅니다.

현재 버전의 제한
- 이 버전은 AI가 아니라 로컬 규칙 기반 추천입니다.
- 기본 추천 템플릿이 보유 카드와 맞지 않으면 일반 카드 역할 분류로 조합합니다.
- 진화/영웅 보유 상태와 슬롯을 아직 정확하게 판별하지 않습니다.
- 게임 최신 메타를 자동 업데이트하지 않습니다.
- 카드 이름은 API가 반환하는 영문 이름을 기준으로 합니다.
