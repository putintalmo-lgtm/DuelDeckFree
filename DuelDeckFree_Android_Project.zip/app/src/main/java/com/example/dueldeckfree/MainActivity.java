package com.example.dueldeckfree;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.content.SharedPreferences;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView web;
    private SharedPreferences prefs;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("duel_deck", MODE_PRIVATE);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private class Bridge {
        @JavascriptInterface public String getSavedKey() {
            return prefs.getString("cr_key", "");
        }
        @JavascriptInterface public void saveKey(String key) {
            prefs.edit().putString("cr_key", key == null ? "" : key.trim()).apply();
        }
        @JavascriptInterface public void loadPlayer(String tag) {
            final String apiKey = prefs.getString("cr_key", "");
            executor.execute(() -> {
                String result;
                try {
                    if (apiKey.isEmpty()) throw new Exception("클래시 로얄 API 키를 먼저 입력해 주세요.");
                    String clean = tag.trim().replace("#", "").toUpperCase();
                    String encoded = URLEncoder.encode("#" + clean, "UTF-8");
                    URL url = new URL("https://proxy.royaleapi.dev/v1/players/" + encoded);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("GET");
                    conn.setConnectTimeout(15000);
                    conn.setReadTimeout(20000);
                    conn.setRequestProperty("Authorization", "Bearer " + apiKey);
                    int code = conn.getResponseCode();
                    InputStream is = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    byte[] buf = new byte[4096]; int n;
                    while ((n = is.read(buf)) > 0) out.write(buf, 0, n);
                    String body = out.toString("UTF-8");
                    conn.disconnect();
                    if (code != 200) throw new Exception("API 오류 " + code + ": " + body.substring(0, Math.min(180, body.length())));
                    result = new JSONObject().put("ok", true).put("player", new JSONObject(body)).toString();
                } catch (Exception e) {
                    try { result = new JSONObject().put("ok", false).put("error", e.getMessage()).toString(); }
                    catch (Exception ignored) { result = "{\"ok\":false,\"error\":\"요청 실패\"}"; }
                }
                final String payload = result;
                runOnUiThread(() -> web.evaluateJavascript("window.onPlayerLoaded(" +
                    JSONObject.quote(payload) + ")", null));
            });
        }
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        executor.shutdownNow();
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
